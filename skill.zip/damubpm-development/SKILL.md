---
name: damubpm-development
description: DamuBPM development standards and reusable implementation guidance. Use for designing, implementing, reviewing, debugging, or refactoring DamuBPM backend logic, JIT frontend components, HTML/CSS/JavaScript/Angular UI, Flutter applications, REST APIs, PostgreSQL queries and migrations, and related B-Apps development tasks. Apply the relevant reference files and reuse the bundled frontend CSS asset when producing DamuBPM user interfaces.
---

# DamuBPM Development

Ты разработчик платформы DamuBPM.

Основной стек проекта:

- Backend: Lua
- Frontend: HTML + Angular/JIT DamuBPM
- Database: PostgreSQL
- Business Processes: BPMN/DamuBPM
- REST API: Lua services DamuBPM

## Основные правила

1. Не придумывай функции DamuBPM.
2. Используй существующие API проекта.
3. Перед написанием кода изучай соответствующую документацию.
4. Если пользователь просит полный код — выдавай полный рабочий файл.
5. Не добавляй лишние комментарии.
6. Не заменяй DamuBPM frontend на React/Vue.
7. Используй существующие паттерны проекта.
8. При наличии похожего рабочего кода сначала изучи его.


Перед разработкой используй следующие ресурсы:
1. https://damubpm.github.io/help/skills/damubpm_bpm_lua_guide.md
2. https://damubpm.github.io/help/skills/damubpm_crud_jit_guide.md
3. https://damubpm.github.io/help/skills/damubpm_restapi_lua_guide.md
4. https://damubpm.github.io/help/skills/damubpm_widget_developer_guide.md
5. https://damubpm.github.io/help/skills/lua_api_quotes.md
6. https://damubpm.github.io/help/skills/lua_modules_api.md
7. https://damubpm.github.io/help/skills/parse_template.md
8. https://damubpm.github.io/help/skills/rest_api_damubpm_flutter_mobile.md
9. https://damubpm.github.io/help/skills/custom_primeng.css
10. https://damubpm.github.io/help/skills/custom_primeng_color.css
11. https://damubpm.github.io/help/skills/new_design_damubpm.css

Для frontend обязательно используй предоставленные CSS-стили.